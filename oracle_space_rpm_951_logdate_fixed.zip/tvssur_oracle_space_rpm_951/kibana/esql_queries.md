# tvssur ES|QL panel queryleri

Bu dashboardlarda Kibana time picker aralığı `@timestamp` yerine doğrudan kaynak verinin `log_date` alanına uygulanır.
Yani `Last 7 days` seçildiğinde fark hesabı o aralıktaki ilk ve son `LOG_DATE` snapshot değerinden yapılır.

## Table dashboard

### TOTAL_DATAFILES current MB
```esql
FROM tvssur-table-space-v1
| WHERE metric_group == "TOTAL_SPACE_DAILY" AND object_name == "TOTAL_DATAFILES"
  AND log_date >= ?_tstart AND log_date < ?_tend
| STATS total_space_mb = LAST(total_space_mb, log_date) BY entity_name
| KEEP entity_name, total_space_mb
```

### TOTAL_DATAFILES diff MB in selected range
```esql
FROM tvssur-table-space-v1
| WHERE metric_group == "TOTAL_SPACE_DAILY" AND object_name == "TOTAL_DATAFILES"
  AND log_date >= ?_tstart AND log_date < ?_tend
| STATS first_size_mb = FIRST(total_space_mb, log_date), last_size_mb = LAST(total_space_mb, log_date) BY entity_name
| EVAL diff_mb = last_size_mb - first_size_mb
| KEEP entity_name, diff_mb
```

### TOTAL_DATAFILES trend
```esql
FROM tvssur-table-space-v1
| WHERE metric_group == "TOTAL_SPACE_DAILY" AND object_name == "TOTAL_DATAFILES"
  AND log_date >= ?_tstart AND log_date < ?_tend
| STATS total_space_mb = MAX(total_space_mb) BY log_day_str
| SORT log_day_str ASC
```

### Top 10 table total size MB
```esql
FROM tvssur-table-space-v1
| WHERE metric_group == "TABLE_DAILY" AND log_date >= ?_tstart AND log_date < ?_tend
| STATS size_mb = LAST(current_size_mb, log_date) BY entity_name
| SORT size_mb DESC
| LIMIT 10
```

### Top 10 non-partition table size MB
```esql
FROM tvssur-table-space-v1
| WHERE metric_group == "TABLE_ONLY_DAILY" AND log_date >= ?_tstart AND log_date < ?_tend
| STATS size_mb = LAST(current_size_mb, log_date) BY entity_name
| SORT size_mb DESC
| LIMIT 10
```

### Top 10 table growth MB in selected range
```esql
FROM tvssur-table-space-v1
| WHERE metric_group == "TABLE_DAILY" AND log_date >= ?_tstart AND log_date < ?_tend
| STATS first_size_mb = FIRST(current_size_mb, log_date), last_size_mb = LAST(current_size_mb, log_date) BY entity_name
| EVAL diff_mb = last_size_mb - first_size_mb
| WHERE diff_mb > 0
| SORT diff_mb DESC
| LIMIT 10
| KEEP entity_name, diff_mb
```

### Top 10 table growth % in selected range
```esql
FROM tvssur-table-space-v1
| WHERE metric_group == "TABLE_DAILY" AND log_date >= ?_tstart AND log_date < ?_tend
| STATS first_size_mb = FIRST(current_size_mb, log_date), last_size_mb = LAST(current_size_mb, log_date) BY entity_name
| EVAL diff_mb = last_size_mb - first_size_mb
| EVAL pct_change = CASE(first_size_mb == 0, null, diff_mb / first_size_mb * 100)
| WHERE pct_change > 0
| SORT pct_change DESC
| LIMIT 10
| KEEP entity_name, pct_change
```

## Index dashboard

### Top 10 index total size MB
```esql
FROM tvssur-index-space-v1
| WHERE metric_group == "INDEX_DAILY" AND log_date >= ?_tstart AND log_date < ?_tend
| STATS size_mb = LAST(current_size_mb, log_date) BY entity_name
| SORT size_mb DESC
| LIMIT 10
```

### Top 10 non-partition index size MB
```esql
FROM tvssur-index-space-v1
| WHERE metric_group == "INDEX_ONLY_DAILY" AND log_date >= ?_tstart AND log_date < ?_tend
| STATS size_mb = LAST(current_size_mb, log_date) BY entity_name
| SORT size_mb DESC
| LIMIT 10
```

### Top 10 index growth MB in selected range
```esql
FROM tvssur-index-space-v1
| WHERE metric_group == "INDEX_DAILY" AND log_date >= ?_tstart AND log_date < ?_tend
| STATS first_size_mb = FIRST(current_size_mb, log_date), last_size_mb = LAST(current_size_mb, log_date) BY entity_name
| EVAL diff_mb = last_size_mb - first_size_mb
| WHERE diff_mb > 0
| SORT diff_mb DESC
| LIMIT 10
| KEEP entity_name, diff_mb
```
