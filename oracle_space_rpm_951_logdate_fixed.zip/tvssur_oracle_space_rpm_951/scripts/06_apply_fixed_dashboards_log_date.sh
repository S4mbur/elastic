#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DASH_DIR="${DASH_DIR:-/data/logstash/dashboards}"

mkdir -p "${DASH_DIR}"
cp "${ROOT_DIR}/dashboards_api/tvssur-table.dashboard.json" "${DASH_DIR}/tvssur-table.dashboard.json"
cp "${ROOT_DIR}/dashboards_api/tvssur-index.dashboard.json" "${DASH_DIR}/tvssur-index.dashboard.json"

python3 -m json.tool "${DASH_DIR}/tvssur-table.dashboard.json" >/dev/null
python3 -m json.tool "${DASH_DIR}/tvssur-index.dashboard.json" >/dev/null

echo "Fixed dashboards copied to ${DASH_DIR}"
echo "table panels: $(python3 -c 'import json;print(len(json.load(open("'"${DASH_DIR}"'/tvssur-table.dashboard.json"))["panels"]))')"
echo "index panels: $(python3 -c 'import json;print(len(json.load(open("'"${DASH_DIR}"'/tvssur-index.dashboard.json"))["panels"]))')"
