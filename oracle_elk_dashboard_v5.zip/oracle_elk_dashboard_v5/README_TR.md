# Oracle 26ai → Logstash → Elasticsearch → Kibana Space Dashboard v5

Bu paket `TB_DB_SPACE_LOG` tablosundan günlük space snapshot verilerini alır ve Kibana'da hazır dashboard oluşturur.

## Paket içeriği

```text
oracle_elk_dashboard_v5/
├── docker-compose.yml
├── .env.example
├── logstash/
│   ├── drivers/
│   │   └── ojdbc11.jar  <-- bunu sen koyacaksın
│   ├── data/
│   └── pipeline/
│       └── oracle-table.conf
└── scripts/
    ├── create_index_v5.sh
    ├── create_oracle_space_dashboard_v5.py
    ├── deploy_v5.sh
    └── check_v5.sh
```

## Ne yapıyor?

Index: `oracle-space-dashboard-v5`

Dashboard: `oracle-space-dashboard-v5`

Dashboard panelleri:

1. **Top 10 Current Table Size MB**  
   En büyük 10 tabloyu gösterir.

2. **Top 10 Adjustable Table Growth %**  
   `1 / 2 / 3 / 5 / 7 / 14 / 30` gün önceye göre yüzde ve MB farkını gösterir.

3. **Total Space Trend**  
   `LOG_TYPE = TOTAL_SPACE` kayıtlarından günlük total space trendini gösterir.

## Dahil edilen segment tipleri

Şunlar birlikte toplanır:

```text
TABLE
TABLE PARTITION
TABLE SUBPARTITION
```

Aynı `OWNER + OBJECT_NAME` altında tek table total olarak gösterilir.

## Hariç tutulan obje

Dashboard için kullanılan tablo hariç tutulur:

```text
TB_DB_SPACE_LOG
```

## Kurulum

Zip'i aç:

```bash
unzip oracle_elk_dashboard_v5.zip
cd oracle_elk_dashboard_v5
```

`.env` oluştur:

```bash
cp .env.example .env
nano .env
```

Oracle bilgilerini düzelt:

```env
ORACLE_JDBC_URL=jdbc:oracle:thin:@//tstvtbdb-scan:3000/takascdb.takasdom.takasbank.com.tr
ORACLE_USER=logstash_user
ORACLE_PASSWORD=YourStrongPassword
```

Oracle JDBC jar dosyasını koy:

```bash
cp /path/to/ojdbc11.jar logstash/drivers/ojdbc11.jar
chmod 644 logstash/drivers/ojdbc11.jar
chmod 755 logstash/drivers
mkdir -p logstash/data
chmod 775 logstash/data
```

RHEL/SELinux varsa `docker-compose.yml` içinde volume satırlarında `:Z` olan alternatifi kullan.

## Tek komutla deploy

```bash
./scripts/deploy_v5.sh
```

Dashboard URL:

```text
http://localhost:5601/app/dashboards#/view/oracle-space-dashboard-v5
```

Başka makineden açıyorsan `localhost` yerine Kibana IP'sini kullan.

## Manuel çalıştırma

```bash
docker compose up -d elasticsearch kibana
./scripts/create_index_v5.sh
docker compose up -d --force-recreate logstash
python3 scripts/create_oracle_space_dashboard_v5.py
```

## Kontrol

```bash
./scripts/check_v5.sh
```

veya:

```bash
docker compose logs -f logstash
curl "http://localhost:9200/oracle-space-dashboard-v5/_count?pretty"
```

## Kibana offline telemetry logları

`docker-compose.yml` içinde Kibana için telemetry kapalı ayarları eklidir:

```yaml
TELEMETRY_ENABLED=false
TELEMETRY_OPTIN=false
NEWSFEED_ENABLED=false
XPACK_SECURITYSOLUTION_ENABLED=false
```

Bu ayarlara rağmen bazı eski saved object/task logları görürsen dashboard verisini etkilemeyebilir.
