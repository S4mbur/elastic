#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

echo "1) Elasticsearch/Kibana/Logstash container'ları başlatılıyor..."
docker compose up -d elasticsearch kibana

echo "2) Elasticsearch index oluşturuluyor..."
./scripts/create_index_v5.sh

echo "3) Logstash başlatılıyor/restart ediliyor..."
docker compose up -d --force-recreate logstash

echo "4) 20 saniye bekleniyor; Logstash ilk query'yi çalıştırmaya başlasın..."
sleep 20

echo "5) Dashboard oluşturuluyor..."
python3 ./scripts/create_oracle_space_dashboard_v5.py

echo
echo "Kontrol komutları:"
echo "  docker compose logs -f logstash"
echo "  ./scripts/check_v5.sh"
