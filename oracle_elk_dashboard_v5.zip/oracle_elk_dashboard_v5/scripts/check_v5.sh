#!/usr/bin/env bash
set -euo pipefail

ES_URL="${ES_URL:-http://localhost:9200}"
INDEX="oracle-space-dashboard-v5"

echo "Index count:"
curl "$ES_URL/$INDEX/_count?pretty"

echo
echo "Sample TABLE_CURRENT:"
curl "$ES_URL/$INDEX/_search?pretty&size=1&q=metric_group:TABLE_CURRENT"

echo
echo "Sample TABLE_GROWTH:"
curl "$ES_URL/$INDEX/_search?pretty&size=1&q=metric_group:TABLE_GROWTH"

echo
echo "Sample TOTAL_SPACE_DAILY:"
curl "$ES_URL/$INDEX/_search?pretty&size=1&q=metric_group:TOTAL_SPACE_DAILY"
