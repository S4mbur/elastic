#!/usr/bin/env bash
set -euo pipefail

ES_URL="${ES_URL:-http://localhost:9200}"
INDEX="oracle-space-dashboard-v5"

curl -s -X DELETE "$ES_URL/$INDEX" >/dev/null || true

echo "Creating index $INDEX on $ES_URL ..."
curl -X PUT "$ES_URL/$INDEX" \
  -H "Content-Type: application/json" \
  -d '{
    "settings": {
      "index.max_result_window": 100000
    },
    "mappings": {
      "properties": {
        "@timestamp": {"type": "date"},
        "source_db": {"type": "keyword"},
        "metric_type": {"type": "keyword"},
        "metric_group": {"type": "keyword"},
        "owner": {"type": "keyword"},
        "object_name": {"type": "keyword"},
        "entity_name": {"type": "keyword"},
        "segment_type": {"type": "keyword"},
        "log_day": {"type": "date"},
        "log_day_str": {"type": "keyword"},
        "day_num": {"type": "integer"},
        "period_days": {"type": "integer"},
        "log_date": {"type": "date"},
        "current_size_mb": {"type": "double"},
        "previous_size_mb": {"type": "double"},
        "diff_mb": {"type": "double"},
        "pct_change": {"type": "double"},
        "total_space_mb": {"type": "double"},
        "doc_id": {"type": "keyword"}
      }
    }
  }'

echo
