import json
import os
import urllib.request
import urllib.error

KIBANA_URL = os.environ.get("KIBANA_URL", "http://localhost:5601").rstrip("/")
INDEX = os.environ.get("ES_INDEX", "oracle-space-dashboard-v5")
DASHBOARD_ID = "oracle-space-dashboard-v5"


def es_query(metric_group, size=50000):
    return {
        "index": INDEX,
        "body": {
            "size": size,
            "_source": [
                "metric_group",
                "entity_name",
                "owner",
                "object_name",
                "log_day_str",
                "day_num",
                "period_days",
                "current_size_mb",
                "previous_size_mb",
                "diff_mb",
                "pct_change",
                "total_space_mb",
            ],
            "query": {"term": {"metric_group": metric_group}},
        },
    }


def current_size_bar_spec():
    return {
        "description": "Top 10 current table total size",
        "width": 780,
        "height": 330,
        "autosize": "none",
        "padding": {"left": 360, "right": 120, "top": 20, "bottom": 45},
        "data": [
            {
                "name": "rows",
                "url": es_query("TABLE_CURRENT", 20000),
                "format": {"property": "hits.hits"},
                "transform": [
                    {"type": "formula", "as": "entity", "expr": "datum._source.entity_name"},
                    {"type": "formula", "as": "value", "expr": "+datum._source.current_size_mb"},
                    {"type": "filter", "expr": "datum.entity != null && isValid(datum.value)"},
                    {"type": "collect", "sort": {"field": "value", "order": "descending"}},
                    {"type": "window", "ops": ["row_number"], "as": ["rank"]},
                    {"type": "filter", "expr": "datum.rank <= 10"},
                ],
            }
        ],
        "scales": [
            {
                "name": "yscale",
                "type": "band",
                "domain": {"data": "rows", "field": "entity"},
                "range": "height",
                "padding": 0.18,
            },
            {
                "name": "xscale",
                "type": "linear",
                "domain": {"data": "rows", "field": "value"},
                "range": "width",
                "nice": True,
                "zero": True,
            },
        ],
        "axes": [
            {
                "orient": "left",
                "scale": "yscale",
                "labelLimit": 340,
                "labelFontSize": 11,
                "title": "Table",
            },
            {
                "orient": "bottom",
                "scale": "xscale",
                "title": "Size MB",
                "grid": True,
            },
        ],
        "marks": [
            {
                "type": "rect",
                "from": {"data": "rows"},
                "encode": {
                    "enter": {
                        "y": {"scale": "yscale", "field": "entity"},
                        "height": {"scale": "yscale", "band": 1},
                        "x": {"scale": "xscale", "value": 0},
                        "x2": {"scale": "xscale", "field": "value"},
                        "tooltip": {"signal": "datum.entity + ': ' + format(datum.value, ',.2f') + ' MB'"},
                    }
                },
            },
            {
                "type": "text",
                "from": {"data": "rows"},
                "encode": {
                    "enter": {
                        "y": {"scale": "yscale", "field": "entity", "band": 0.5},
                        "x": {"scale": "xscale", "field": "value", "offset": 6},
                        "align": {"value": "left"},
                        "baseline": {"value": "middle"},
                        "fontSize": {"value": 11},
                        "text": {"signal": "format(datum.value, ',.2f') + ' MB'"},
                    }
                },
            },
        ],
    }


def growth_bar_spec():
    return {
        "description": "Top 10 adjustable table growth",
        "width": 780,
        "height": 330,
        "autosize": "none",
        "padding": {"left": 360, "right": 180, "top": 45, "bottom": 45},
        "signals": [
            {
                "name": "daysBack",
                "value": 3,
                "bind": {
                    "input": "select",
                    "options": [1, 2, 3, 5, 7, 14, 30],
                    "name": "Kaç gün önce: ",
                },
            }
        ],
        "data": [
            {
                "name": "rows_raw",
                "url": es_query("TABLE_GROWTH", 100000),
                "format": {"property": "hits.hits"},
                "transform": [
                    {"type": "formula", "as": "entity", "expr": "datum._source.entity_name"},
                    {"type": "formula", "as": "period", "expr": "+datum._source.period_days"},
                    {"type": "formula", "as": "pct", "expr": "+datum._source.pct_change"},
                    {"type": "formula", "as": "diff", "expr": "+datum._source.diff_mb"},
                    {"type": "formula", "as": "cur", "expr": "+datum._source.current_size_mb"},
                    {"type": "formula", "as": "prev", "expr": "+datum._source.previous_size_mb"},
                    {"type": "filter", "expr": "datum.period == daysBack && datum.entity != null && isValid(datum.pct)"},
                    {"type": "collect", "sort": {"field": "pct", "order": "descending"}},
                    {"type": "window", "ops": ["row_number"], "as": ["rank"]},
                    {"type": "filter", "expr": "datum.rank <= 10"},
                ],
            }
        ],
        "scales": [
            {
                "name": "yscale",
                "type": "band",
                "domain": {"data": "rows_raw", "field": "entity"},
                "range": "height",
                "padding": 0.18,
            },
            {
                "name": "xscale",
                "type": "linear",
                "domain": {"data": "rows_raw", "field": "pct"},
                "range": "width",
                "nice": True,
                "zero": True,
            },
        ],
        "axes": [
            {
                "orient": "left",
                "scale": "yscale",
                "labelLimit": 340,
                "labelFontSize": 11,
                "title": "Table",
            },
            {
                "orient": "bottom",
                "scale": "xscale",
                "title": "Growth %",
                "grid": True,
            },
        ],
        "marks": [
            {
                "type": "rect",
                "from": {"data": "rows_raw"},
                "encode": {
                    "enter": {
                        "y": {"scale": "yscale", "field": "entity"},
                        "height": {"scale": "yscale", "band": 1},
                        "x": {"scale": "xscale", "value": 0},
                        "x2": {"scale": "xscale", "field": "pct"},
                        "tooltip": {
                            "signal": "datum.entity + '\\nCurrent: ' + format(datum.cur, ',.2f') + ' MB\\nPrevious: ' + format(datum.prev, ',.2f') + ' MB\\nDiff: ' + format(datum.diff, ',.2f') + ' MB\\nGrowth: ' + format(datum.pct, ',.2f') + '%'"
                        },
                    }
                },
            },
            {
                "type": "text",
                "from": {"data": "rows_raw"},
                "encode": {
                    "enter": {
                        "y": {"scale": "yscale", "field": "entity", "band": 0.5},
                        "x": {"scale": "xscale", "field": "pct", "offset": 6},
                        "align": {"value": "left"},
                        "baseline": {"value": "middle"},
                        "fontSize": {"value": 11},
                        "text": {"signal": "format(datum.pct, ',.2f') + '% / ' + format(datum.diff, ',.2f') + ' MB'"},
                    }
                },
            },
        ],
    }


def total_space_line_spec():
    return {
        "description": "Total space trend",
        "width": 1620,
        "height": 300,
        "autosize": "none",
        "padding": {"left": 90, "right": 60, "top": 20, "bottom": 70},
        "data": [
            {
                "name": "rows",
                "url": es_query("TOTAL_SPACE_DAILY", 1000),
                "format": {"property": "hits.hits"},
                "transform": [
                    {"type": "formula", "as": "day", "expr": "datum._source.log_day_str"},
                    {"type": "formula", "as": "dayNum", "expr": "+datum._source.day_num"},
                    {"type": "formula", "as": "value", "expr": "+datum._source.total_space_mb"},
                    {"type": "filter", "expr": "datum.day != null && isValid(datum.value)"},
                    {"type": "collect", "sort": {"field": "dayNum", "order": "ascending"}},
                ],
            }
        ],
        "scales": [
            {
                "name": "xscale",
                "type": "point",
                "domain": {"data": "rows", "field": "day"},
                "range": "width",
                "padding": 0.5,
            },
            {
                "name": "yscale",
                "type": "linear",
                "domain": {"data": "rows", "field": "value"},
                "range": "height",
                "nice": True,
                "zero": False,
            },
        ],
        "axes": [
            {
                "orient": "bottom",
                "scale": "xscale",
                "title": "Day",
                "labelAngle": -45,
                "labelLimit": 85,
            },
            {
                "orient": "left",
                "scale": "yscale",
                "title": "Total space MB",
                "grid": True,
            },
        ],
        "marks": [
            {
                "type": "line",
                "from": {"data": "rows"},
                "encode": {
                    "enter": {
                        "x": {"scale": "xscale", "field": "day"},
                        "y": {"scale": "yscale", "field": "value"},
                        "strokeWidth": {"value": 2},
                    }
                },
            },
            {
                "type": "symbol",
                "from": {"data": "rows"},
                "encode": {
                    "enter": {
                        "x": {"scale": "xscale", "field": "day"},
                        "y": {"scale": "yscale", "field": "value"},
                        "size": {"value": 45},
                        "tooltip": {"signal": "datum.day + ': ' + format(datum.value, ',.2f') + ' MB'"},
                    }
                },
            },
        ],
    }


def visualization_obj(obj_id, title, spec):
    vis_state = {
        "title": title,
        "type": "vega",
        "params": {"spec": json.dumps(spec, indent=2)},
        "aggs": [],
    }

    return {
        "type": "visualization",
        "id": obj_id,
        "attributes": {
            "title": title,
            "description": "",
            "version": 1,
            "visState": json.dumps(vis_state),
            "uiStateJSON": "{}",
            "kibanaSavedObjectMeta": {
                "searchSourceJSON": json.dumps({"query": {"query": "", "language": "kuery"}, "filter": []})
            },
        },
        "references": [],
    }


viz_size_id = "oracle-v5-current-size"
viz_growth_id = "oracle-v5-adjustable-growth"
viz_total_id = "oracle-v5-total-space"

objects = [
    visualization_obj(viz_size_id, "Top 10 Current Table Size MB", current_size_bar_spec()),
    visualization_obj(viz_growth_id, "Top 10 Adjustable Table Growth %", growth_bar_spec()),
    visualization_obj(viz_total_id, "Total Space Trend", total_space_line_spec()),
]

panels = [
    {
        "version": "9.4.2",
        "type": "visualization",
        "gridData": {"x": 0, "y": 0, "w": 24, "h": 16, "i": "1"},
        "panelIndex": "1",
        "embeddableConfig": {},
        "panelRefName": "panel_1",
    },
    {
        "version": "9.4.2",
        "type": "visualization",
        "gridData": {"x": 24, "y": 0, "w": 24, "h": 16, "i": "2"},
        "panelIndex": "2",
        "embeddableConfig": {},
        "panelRefName": "panel_2",
    },
    {
        "version": "9.4.2",
        "type": "visualization",
        "gridData": {"x": 0, "y": 16, "w": 48, "h": 15, "i": "3"},
        "panelIndex": "3",
        "embeddableConfig": {},
        "panelRefName": "panel_3",
    },
]

objects.append(
    {
        "type": "dashboard",
        "id": DASHBOARD_ID,
        "attributes": {
            "title": "Oracle Space Dashboard v5",
            "description": "Oracle table size, adjustable growth, and total space trend.",
            "panelsJSON": json.dumps(panels),
            "optionsJSON": json.dumps(
                {"useMargins": True, "syncColors": False, "syncCursor": True, "syncTooltips": False}
            ),
            "version": 1,
            "timeRestore": False,
            "kibanaSavedObjectMeta": {
                "searchSourceJSON": json.dumps({"query": {"query": "", "language": "kuery"}, "filter": []})
            },
        },
        "references": [
            {"name": "panel_1", "type": "visualization", "id": viz_size_id},
            {"name": "panel_2", "type": "visualization", "id": viz_growth_id},
            {"name": "panel_3", "type": "visualization", "id": viz_total_id},
        ],
    }
)

payload = json.dumps(objects).encode("utf-8")

req = urllib.request.Request(
    KIBANA_URL + "/api/saved_objects/_bulk_create?overwrite=true",
    data=payload,
    method="POST",
    headers={"Content-Type": "application/json", "kbn-xsrf": "true"},
)

try:
    with urllib.request.urlopen(req) as resp:
        print(resp.read().decode("utf-8"))
        print()
        print("Dashboard hazir:")
        print(KIBANA_URL + "/app/dashboards#/view/" + DASHBOARD_ID)
except urllib.error.HTTPError as e:
    print("HTTP ERROR:", e.code)
    print(e.read().decode("utf-8"))
    raise
