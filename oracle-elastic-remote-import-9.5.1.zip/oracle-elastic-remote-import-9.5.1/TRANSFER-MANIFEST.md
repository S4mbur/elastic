# Transfer manifesti

## Zorunlu Elasticsearch dosyaları

```text
elasticsearch/ilm/oracle-space-history.json
elasticsearch/templates/oracle-space-history.json
elasticsearch/templates/oracle-space-current.json
elasticsearch/transforms/oracle-space-current.json
elasticsearch/security/oracle-space-writer-role.json
elasticsearch/security/oracle-space-reader-role.json
```

## Zorunlu Kibana dosyası

```text
kibana/oracle-space-dashboard.ndjson
```

`kibana/vega/*.json` dosyaları dashboard NDJSON içine gömülüdür; import için ayrıca yüklenmez. Bakım ve düzenleme amacıyla pakete eklenmiştir.

## Zorunlu Logstash dosyaları

```text
logstash/Dockerfile
logstash/config/logstash.yml
logstash/config/pipelines.yml
logstash/pipeline/live/10-input-logdate-incremental.conf
logstash/pipeline/common/50-normalize.conf
logstash/pipeline/common/99-output.conf
logstash/sql/live/segments_incremental.sql
logstash/sql/live/tablespaces_incremental.sql
logstash/sql/live/database_incremental.sql
```

## Backfill dosyaları

```text
logstash/pipeline/backfill/10-input.conf
logstash/sql/segments_daily.sql
logstash/sql/tablespaces_daily.sql
logstash/sql/database_daily.sql
```

## Opsiyonel Oracle collector

```text
oracle-sql/00_prerequisites_as_dba.sql
oracle-sql/10_harden_existing_table.sql
oracle-sql/20_capture_package.sql
oracle-sql/30_scheduler_jobs.sql
oracle-sql/40_operational_checks.sql
```

## Kurulum yardımcıları

```text
.env.remote.example
compose-logstash.yaml
install/01-install-elasticsearch.sh
install/02-install-kibana.sh
install/03-start-transform.sh
install/04-verify.sh
certs/ca.crt                         Kullanıcı tarafından eklenecek
```

## Taşınmaması gerekenler

- Eski kurulumun `.env` dosyası ve parolaları
- Yerel Elasticsearch/Kibana data volume'ları
- Yerel CA/private key dosyaları
- Ana paketteki full-stack `compose.yaml` (hedefte Elastic zaten çalışıyor)

