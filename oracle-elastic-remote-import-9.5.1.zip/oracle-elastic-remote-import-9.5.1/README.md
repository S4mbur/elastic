# Oracle DB Space — Mevcut Elastic'e Aktarım Paketi 9.5.1

Bu klasör yeni bir Elasticsearch/Kibana cluster'ı kurmaz. Çalışan Elastic 9.5.1 ortamına Oracle table/index alan izleme sistemini eklemek için gereken Elasticsearch varlıklarını, Kibana dashboard'u, Vega kaynaklarını, Logstash conf/SQL dosyalarını ve kurulum scriptlerini içerir.

## Vega kurulacak mı?

Hayır. Vega ve Vega-Lite Kibana'nın **Custom visualization** özelliğinin içinde gelir; ayrıca plugin, npm paketi veya Vega servisi kurulmaz. `kibana/oracle-space-dashboard.ndjson` import edildiğinde Vega tanımları saved object içinde taşınır. `kibana/vega/` klasörü kaynak kod ve bakım içindir. Grafikler dış URL kullanmadığı için `vis_type_vega.enableExternalUrls` açılması da gerekmez.

Bu paket Kibana 9.5.1 üzerinde üretildi. Daha eski Kibana'ya NDJSON import etmeyin. Hedef Elasticsearch ve Kibana sürümleri birbiriyle uyumlu olmalıdır.

## Paket içeriği

```text
elasticsearch/     ILM, index template, transform ve security role tanımları
kibana/            Import edilecek NDJSON ve altı Vega kaynak dosyası
logstash/          JDBC input, normalize/output conf, SQL ve OJDBC image'i
oracle-sql/        Opsiyonel Oracle collector/scheduler SQL'leri
install/           Mevcut ES/Kibana'ya yükleme ve doğrulama scriptleri
certs/             Hedef Elastic/Kibana CA sertifikasının konacağı klasör
compose-logstash.yaml  Yalnız Logstash'i ayağa kaldıran compose
.env.remote.example    Parolasız örnek ortam dosyası
TRANSFER-MANIFEST.md   Taşınacak dosyaların ayrıntılı listesi
```

`compose-logstash.yaml` Elasticsearch veya Kibana container'ı başlatmaz; sadece mevcut uzak Elastic'e yazan Logstash'i çalıştırır.

## 1. Ortam ve CA hazırlığı

```bash
cp .env.remote.example .env.remote
```

`.env.remote` içindeki Oracle, Elasticsearch, Kibana adreslerini ve kullanıcıları doldurun. Hedef Elasticsearch HTTP CA sertifikasını şu adla yerleştirin:

```text
certs/ca.crt
```

Kurulum scriptleri için değişkenleri shell'e alın:

```bash
set -a
. ./.env.remote
set +a
```

## 2. Elasticsearch varlıklarını yükleme

Yetkili kullanıcı `manage_ilm`, `manage_index_templates`, `manage_transform` ve security role yönetim yetkilerine sahip olmalıdır.

```bash
bash install/01-install-elasticsearch.sh
```

Script şunları yükler:

- `oracle-space-history` ILM policy
- History/current index template'ları
- `oracle_space_writer` ve `oracle_space_reader` index rolleri
- `oracle-space-current` continuous transform tanımı

Logstash kullanıcısını mevcut kimlik yönetiminizde oluşturun veya var olan service account/kullanıcıya `oracle_space_writer` rolünü verin. Örnek Elasticsearch API gövdesi:

```json
PUT /_security/user/logstash_oracle
{
  "password": "GÜÇLÜ_PAROLA",
  "roles": ["oracle_space_writer"]
}
```

## 3. Kibana dashboard importu

```bash
bash install/02-install-kibana.sh
```

Bu script exact ID'lerle iki data view oluşturur ve `kibana/oracle-space-dashboard.ndjson` dosyasını overwrite modunda import eder:

| Data view ID | Pattern | Time field |
|---|---|---|
| `oracle-db-space-history` | `oracle-db-space-history-*` | `@timestamp` |
| `oracle-db-space-current` | `oracle-db-space-current-v1` | Yok |

Başka bir Kibana Space kullanıyorsanız `.env.remote` içinde `KIBANA_SPACE_ID` ayarlayın.

## 4. LOG_DATE artımlı Logstash'i başlatma

```bash
docker compose -f compose-logstash.yaml --env-file .env.remote up -d --build logstash
```

Logstash sağlık ve log kontrolü:

```bash
curl http://localhost:9600/_node/pipelines?pretty
docker compose -f compose-logstash.yaml logs -f logstash
```

İlk history belgeleri geldikten sonra current transform'u başlatın:

```bash
bash install/03-start-transform.sh
```

Kontrol:

```bash
bash install/04-verify.sh
```

## LOG_DATE ve duplicate davranışı

Canlı JDBC conf'u `logstash/pipeline/live/10-input-logdate-incremental.conf` dosyasıdır. Üç input kendi `sql_last_value` state dosyasına sahiptir ve `tracking_log_date` üzerinden ilerler:

```text
/usr/share/logstash/data/.oracle_segments_last_run.yml
/usr/share/logstash/data/.oracle_tablespaces_last_run.yml
/usr/share/logstash/data/.oracle_database_last_run.yml
```

`logstash_state` Docker volume'u bu dosyaları kalıcı tutar. Container yeniden başlasa bile watermark kaybolmaz.

Akış şu şekildedir:

1. İlk çalıştırmada yalnız `INITIAL_LOOKBACK_DAYS` kadar veri okunur; varsayılan 3 gündür.
2. Sonraki sorgular `LOG_DATE >= sql_last_value - JDBC_OVERLAP_MINUTES` koşulunu kullanır.
3. Varsayılan 120 dakikalık overlap, geç commit edilen satırların kaçmasını önler.
4. SQL sonuçları `tracking_log_date ASC` sıralıdır; state en yeni `LOG_DATE` değerinde kalır.
5. `@timestamp` doğrudan Oracle `LOG_DATE` alanından üretilir.
6. Elasticsearch `_id`, kaynak DB + nesne türü + owner + nesne adı + `TRUNC(LOG_DATE)` ile deterministiktir.

Sonuç olarak aynı satır tekrar okunursa duplicate oluşmaz; aynı nesnenin aynı gündeki daha yeni job snapshot'ı günlük dokümanı günceller. Yeni takvim günü yeni history dokümanı oluşturur.

Bu davranış özellikle önemlidir: job aynı gün içinde birçok snapshot yazsa bile bütün snapshot'ları toplamak table/index boyutunu yanlış katlar. Sistem her nesne için **günün en yeni LOG_DATE snapshot'ını** tutar ve günlük trendi onun üzerinden hesaplar.

`clean_run` değerini `true` yapmayın ve `logstash_state` volume'unu silmeyin. State yanlışlıkla sıfırlansa bile deterministik document ID duplicate oluşmasını engeller; ancak ilk lookback aralığı Oracle'dan tekrar okunur.

## Eski veriyi bir defalık yükleme

Canlı pipeline ilk çalıştırmada tüm tabloyu taramaz. Örneğin 365 günlük geçmiş için:

```bash
docker compose -f compose-logstash.yaml --env-file .env.remote \
  --profile backfill run --rm logstash-backfill
```

`BACKFILL_DAYS` `.env.remote` içinde ayarlanır. Backfill de aynı document ID'leri kullandığı için canlı pipeline ile duplicate üretmez.

## Oracle tarafı

Mevcut job `VTB.TB_DB_SPACE_LOG` tablosuna `SEGMENT` kayıtlarını sürekli yazıyorsa table/index trendleri için mevcut job kullanılabilir. Aşağıdaki alanlar dolu olmalıdır:

```text
LOG_DATE, LOG_TYPE, SEGMENT_TYPE, OWNER, OBJECT_NAME, SIZE_MB
```

Tablespace ve database kapasite panelleri için ayrıca `TABLESPACE_ALLOCATED/USED/FREE/MAX` ve `TOTAL_SPACE/USED/FREE/MAX` kayıtları gerekir. Mevcut job bunları üretmiyorsa `oracle-sql/20_capture_package.sql` ve `30_scheduler_jobs.sql` kullanılabilir.

## Logstash Docker dışında çalışıyorsa

`logstash/config`, `logstash/pipeline` ve `logstash/sql` klasörlerini Logstash sunucusuna kopyalayın. `ojdbc11.jar` dosyasını `/usr/share/logstash/drivers/ojdbc11.jar` konumuna koyun. `99-output.conf` içindeki `ES_CA_PATH` hedef CA dosyasını göstermelidir. JDBC state dizini kalıcı disk üzerinde olmalıdır.

## SLM dosyaları

`elasticsearch/slm/` opsiyoneldir. Snapshot repository yolu her cluster'da farklı olduğu için otomatik kurulum scripti SLM'i yüklemez. Hedef cluster'ın repository ayarına göre ayrıca uygulanmalıdır.

