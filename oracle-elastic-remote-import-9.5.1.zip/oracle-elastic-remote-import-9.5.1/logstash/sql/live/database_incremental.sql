WITH ranked AS (
    SELECT
        UPPER(REPLACE(log_type, ' ', '_')) AS metric_name,
        TRUNC(log_date) AS log_day,
        log_date,
        size_mb,
        ROW_NUMBER() OVER (
            PARTITION BY UPPER(REPLACE(log_type, ' ', '_')), TRUNC(log_date)
            ORDER BY log_date DESC
        ) AS row_num
    FROM VTB.TB_DB_SPACE_LOG
    WHERE log_date >= CASE
            WHEN CAST(:sql_last_value AS TIMESTAMP) < TIMESTAMP '2000-01-01 00:00:00'
                THEN CAST(SYSDATE AS TIMESTAMP) - NUMTODSINTERVAL(:initial_lookback_days, 'DAY')
            ELSE CAST(:sql_last_value AS TIMESTAMP) - NUMTODSINTERVAL(:overlap_minutes, 'MINUTE')
        END
      AND (
          UPPER(REPLACE(log_type, ' ', '_')) IN (
              'TOTAL_SPACE', 'TOTAL_USED_SPACE', 'TOTAL_FREE_SPACE', 'TOTAL_MAX_SPACE'
          )
          OR UPPER(object_name) = 'TOTAL_DATAFILES'
      )
),
daily AS (
    SELECT
        log_day,
        MAX(log_date) AS log_date,
        MAX(CASE WHEN metric_name = 'TOTAL_SPACE' THEN size_mb END) AS allocated_mb,
        MAX(CASE WHEN metric_name = 'TOTAL_USED_SPACE' THEN size_mb END) AS used_mb,
        MAX(CASE WHEN metric_name = 'TOTAL_FREE_SPACE' THEN size_mb END) AS free_mb,
        MAX(CASE WHEN metric_name = 'TOTAL_MAX_SPACE' THEN size_mb END) AS max_mb
    FROM ranked
    WHERE row_num = 1
    GROUP BY log_day
)
SELECT
    'database' AS metric_dataset,
    'DATABASE' AS owner,
    'TOTAL_DATAFILES' AS object_name,
    'database' AS object_kind,
    'DATABASE_TOTAL' AS object_type,
    log_day,
    log_date,
    log_date AS tracking_log_date,
    NVL(used_mb, allocated_mb) AS size_mb,
    allocated_mb,
    used_mb,
    free_mb,
    max_mb,
    ROUND(used_mb / NULLIF(allocated_mb, 0) * 100, 2) AS used_pct,
    'database|TOTAL_DATAFILES|' || TO_CHAR(log_day, 'YYYYMMDD') AS doc_id
FROM daily
ORDER BY tracking_log_date ASC

