WITH ranked AS (
    SELECT
        object_name AS tablespace_name,
        UPPER(REPLACE(log_type, ' ', '_')) AS metric_name,
        TRUNC(log_date) AS log_day,
        log_date,
        size_mb,
        ROW_NUMBER() OVER (
            PARTITION BY object_name, UPPER(REPLACE(log_type, ' ', '_')), TRUNC(log_date)
            ORDER BY log_date DESC
        ) AS row_num
    FROM VTB.TB_DB_SPACE_LOG
    WHERE log_date >= CASE
            WHEN CAST(:sql_last_value AS TIMESTAMP) < TIMESTAMP '2000-01-01 00:00:00'
                THEN CAST(SYSDATE AS TIMESTAMP) - NUMTODSINTERVAL(:initial_lookback_days, 'DAY')
            ELSE CAST(:sql_last_value AS TIMESTAMP) - NUMTODSINTERVAL(:overlap_minutes, 'MINUTE')
        END
      AND UPPER(REPLACE(log_type, ' ', '_')) IN (
          'TABLESPACE_ALLOCATED', 'TABLESPACE_USED', 'TABLESPACE_FREE', 'TABLESPACE_MAX'
      )
),
daily AS (
    SELECT
        tablespace_name,
        log_day,
        MAX(log_date) AS log_date,
        MAX(CASE WHEN metric_name = 'TABLESPACE_ALLOCATED' THEN size_mb END) AS allocated_mb,
        MAX(CASE WHEN metric_name = 'TABLESPACE_USED' THEN size_mb END) AS used_mb,
        MAX(CASE WHEN metric_name = 'TABLESPACE_FREE' THEN size_mb END) AS free_mb,
        MAX(CASE WHEN metric_name = 'TABLESPACE_MAX' THEN size_mb END) AS max_mb
    FROM ranked
    WHERE row_num = 1
    GROUP BY tablespace_name, log_day
)
SELECT
    'tablespace' AS metric_dataset,
    'DATABASE' AS owner,
    tablespace_name AS object_name,
    'tablespace' AS object_kind,
    'TABLESPACE' AS object_type,
    tablespace_name,
    log_day,
    log_date,
    log_date AS tracking_log_date,
    NVL(used_mb, allocated_mb - NVL(free_mb, 0)) AS size_mb,
    allocated_mb,
    NVL(used_mb, allocated_mb - NVL(free_mb, 0)) AS used_mb,
    free_mb,
    max_mb,
    ROUND(NVL(used_mb, allocated_mb - NVL(free_mb, 0)) / NULLIF(allocated_mb, 0) * 100, 2) AS used_pct,
    'tablespace|' || tablespace_name || '|' || TO_CHAR(log_day, 'YYYYMMDD') AS doc_id
FROM daily
ORDER BY tracking_log_date ASC, tablespace_name ASC

