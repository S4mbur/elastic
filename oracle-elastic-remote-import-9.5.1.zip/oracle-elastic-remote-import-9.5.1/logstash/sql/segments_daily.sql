WITH segment_rows AS (
    SELECT
        owner,
        object_name,
        UPPER(segment_type) AS source_segment_type,
        CASE
            WHEN UPPER(segment_type) IN ('TABLE', 'TABLE PARTITION', 'TABLE SUBPARTITION') THEN 'table'
            WHEN UPPER(segment_type) IN ('INDEX', 'INDEX PARTITION', 'INDEX SUBPARTITION') THEN 'index'
        END AS object_kind,
        TRUNC(log_date) AS log_day,
        log_date,
        size_mb
    FROM VTB.TB_DB_SPACE_LOG
    WHERE log_date >= TRUNC(SYSDATE) - :lookback_days
      AND UPPER(REPLACE(log_type, ' ', '_')) = 'SEGMENT'
      AND UPPER(segment_type) IN (
          'TABLE', 'TABLE PARTITION', 'TABLE SUBPARTITION',
          'INDEX', 'INDEX PARTITION', 'INDEX SUBPARTITION'
      )
      AND NOT (UPPER(owner) = 'VTB' AND UPPER(object_name) = 'TB_DB_SPACE_LOG')
),
snapshot_totals AS (
    SELECT
        owner,
        object_name,
        object_kind,
        log_day,
        log_date,
        SUM(size_mb) AS size_mb
    FROM segment_rows
    GROUP BY owner, object_name, object_kind, log_day, log_date
),
daily_ranked AS (
    SELECT
        s.*,
        ROW_NUMBER() OVER (
            PARTITION BY owner, object_name, object_kind, log_day
            ORDER BY log_date DESC
        ) AS row_num
    FROM snapshot_totals s
)
SELECT
    'segment' AS metric_dataset,
    owner,
    object_name,
    object_kind,
    CASE object_kind WHEN 'table' THEN 'TABLE_TOTAL' ELSE 'INDEX_TOTAL' END AS object_type,
    log_day,
    log_date,
    size_mb,
    object_kind || '|' || owner || '|' || object_name || '|' || TO_CHAR(log_day, 'YYYYMMDD') AS doc_id
FROM daily_ranked
WHERE row_num = 1

