-- VTB olarak çalıştırın. Mevcut aynı isimli job'ları güvenli biçimde günceller.

BEGIN
  FOR J IN (
    SELECT JOB_NAME
      FROM USER_SCHEDULER_JOBS
     WHERE JOB_NAME IN ('DB_SPACE_SEGMENTS_DAILY', 'DB_SPACE_CAPACITY_5M', 'DB_SPACE_PURGE_DAILY')
  ) LOOP
    DBMS_SCHEDULER.DROP_JOB(J.JOB_NAME, FORCE => TRUE);
  END LOOP;

  DBMS_SCHEDULER.CREATE_JOB(
    JOB_NAME        => 'DB_SPACE_SEGMENTS_DAILY',
    JOB_TYPE        => 'STORED_PROCEDURE',
    JOB_ACTION      => 'VTB.PKG_DB_SPACE_OBS.CAPTURE_SEGMENTS',
    START_DATE      => SYSTIMESTAMP,
    REPEAT_INTERVAL => 'FREQ=DAILY;BYHOUR=2;BYMINUTE=15;BYSECOND=0',
    ENABLED         => TRUE,
    AUTO_DROP       => FALSE,
    COMMENTS        => 'Tüm table/index segment boyutlarının günlük snapshotı'
  );

  DBMS_SCHEDULER.CREATE_JOB(
    JOB_NAME        => 'DB_SPACE_CAPACITY_5M',
    JOB_TYPE        => 'STORED_PROCEDURE',
    JOB_ACTION      => 'VTB.PKG_DB_SPACE_OBS.CAPTURE_CAPACITY',
    START_DATE      => SYSTIMESTAMP,
    REPEAT_INTERVAL => 'FREQ=MINUTELY;INTERVAL=5',
    ENABLED         => TRUE,
    AUTO_DROP       => FALSE,
    COMMENTS        => 'Tablespace allocated/used/free/max kapasite snapshotı'
  );

  DBMS_SCHEDULER.CREATE_JOB(
    JOB_NAME        => 'DB_SPACE_PURGE_DAILY',
    JOB_TYPE        => 'PLSQL_BLOCK',
    JOB_ACTION      => 'BEGIN VTB.PKG_DB_SPACE_OBS.PURGE_HISTORY(400); END;',
    START_DATE      => SYSTIMESTAMP,
    REPEAT_INTERVAL => 'FREQ=DAILY;BYHOUR=4;BYMINUTE=10;BYSECOND=0',
    ENABLED         => TRUE,
    AUTO_DROP       => FALSE,
    COMMENTS        => 'Oracle kaynak tablosunda 400 günden eski snapshotları siler'
  );
END;
/

