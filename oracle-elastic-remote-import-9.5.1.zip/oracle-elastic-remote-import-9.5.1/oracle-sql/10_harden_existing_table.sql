-- VTB olarak çalıştırın. Veri silmez; mevcut görseldeki tabloyu genişletir ve sorgu indeksini ekler.

DECLARE
  v_owner_length NUMBER;
  v_index_count  NUMBER;
BEGIN
  SELECT data_length
    INTO v_owner_length
    FROM user_tab_columns
   WHERE table_name = 'TB_DB_SPACE_LOG'
     AND column_name = 'OWNER';

  IF v_owner_length < 128 THEN
    EXECUTE IMMEDIATE 'ALTER TABLE VTB.TB_DB_SPACE_LOG MODIFY (OWNER VARCHAR2(128 BYTE))';
  END IF;

  SELECT COUNT(*)
    INTO v_index_count
    FROM user_indexes
   WHERE index_name = 'IX_DB_SPACE_LOG_LOOKUP';

  IF v_index_count = 0 THEN
    EXECUTE IMMEDIATE q'[
      CREATE INDEX VTB.IX_DB_SPACE_LOG_LOOKUP
          ON VTB.TB_DB_SPACE_LOG (LOG_DATE, LOG_TYPE, SEGMENT_TYPE, OWNER, OBJECT_NAME)
          TABLESPACE VTB
    ]';
  END IF;
END;
/

BEGIN
  DBMS_STATS.GATHER_TABLE_STATS(
    ownname          => 'VTB',
    tabname          => 'TB_DB_SPACE_LOG',
    cascade          => TRUE,
    estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE
  );
END;
/

