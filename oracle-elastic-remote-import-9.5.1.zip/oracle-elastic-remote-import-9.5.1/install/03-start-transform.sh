#!/usr/bin/env bash
set -euo pipefail

: "${ES_URL:?ES_URL tanımlanmalı}"
: "${ES_ADMIN_USER:?ES_ADMIN_USER tanımlanmalı}"
: "${ES_ADMIN_PASSWORD:?ES_ADMIN_PASSWORD tanımlanmalı}"

curl_args=(--silent --show-error --fail-with-body --user "${ES_ADMIN_USER}:${ES_ADMIN_PASSWORD}")
if [[ -n "${ES_CA_CERT:-}" ]]; then
  curl_args+=(--cacert "${ES_CA_CERT}")
fi

curl "${curl_args[@]}" -H 'Content-Type: application/json' \
  -X POST "${ES_URL}/_transform/oracle-space-current/_start"
echo
echo 'oracle-space-current transform başlatıldı.'

