#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
: "${ES_URL:?ES_URL tanımlanmalı}"
: "${ES_ADMIN_USER:?ES_ADMIN_USER tanımlanmalı}"
: "${ES_ADMIN_PASSWORD:?ES_ADMIN_PASSWORD tanımlanmalı}"

curl_args=(--silent --show-error --fail-with-body --user "${ES_ADMIN_USER}:${ES_ADMIN_PASSWORD}")
if [[ -n "${ES_CA_CERT:-}" ]]; then
  curl_args+=(--cacert "${ES_CA_CERT}")
fi

put_file() {
  local endpoint="$1"
  local file="$2"
  curl "${curl_args[@]}" -H 'Content-Type: application/json' \
    -X PUT "${ES_URL}${endpoint}" --data-binary "@${file}"
  echo
}

put_file '/_ilm/policy/oracle-space-history' "${ROOT}/elasticsearch/ilm/oracle-space-history.json"
put_file '/_index_template/oracle-space-history' "${ROOT}/elasticsearch/templates/oracle-space-history.json"
put_file '/_index_template/oracle-space-current' "${ROOT}/elasticsearch/templates/oracle-space-current.json"
put_file '/_security/role/oracle_space_writer' "${ROOT}/elasticsearch/security/oracle-space-writer-role.json"
put_file '/_security/role/oracle_space_reader' "${ROOT}/elasticsearch/security/oracle-space-reader-role.json"

if curl "${curl_args[@]}" "${ES_URL}/_transform/oracle-space-current" >/dev/null 2>&1; then
  echo 'Transform zaten var: oracle-space-current (üzerine yazılmadı).'
else
  put_file '/_transform/oracle-space-current?defer_validation=true' "${ROOT}/elasticsearch/transforms/oracle-space-current.json"
fi

echo 'Elasticsearch ILM, template, roller ve transform tanımı hazır.'

