#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
: "${KIBANA_URL:?KIBANA_URL tanımlanmalı}"
: "${KIBANA_ADMIN_USER:?KIBANA_ADMIN_USER tanımlanmalı}"
: "${KIBANA_ADMIN_PASSWORD:?KIBANA_ADMIN_PASSWORD tanımlanmalı}"

space_prefix=''
if [[ -n "${KIBANA_SPACE_ID:-}" ]]; then
  space_prefix="/s/${KIBANA_SPACE_ID}"
fi

curl_args=(--silent --show-error --fail-with-body --user "${KIBANA_ADMIN_USER}:${KIBANA_ADMIN_PASSWORD}" -H 'kbn-xsrf: oracle-space-import')
if [[ -n "${KIBANA_CA_CERT:-}" ]]; then
  curl_args+=(--cacert "${KIBANA_CA_CERT}")
fi

curl "${curl_args[@]}" -H 'Content-Type: application/json' \
  -X POST "${KIBANA_URL}${space_prefix}/api/data_views/data_view" \
  --data-binary '{"data_view":{"id":"oracle-db-space-history","title":"oracle-db-space-history-*","name":"Oracle DB Space - History","timeFieldName":"@timestamp","allowNoIndex":true},"override":true}'
echo

curl "${curl_args[@]}" -H 'Content-Type: application/json' \
  -X POST "${KIBANA_URL}${space_prefix}/api/data_views/data_view" \
  --data-binary '{"data_view":{"id":"oracle-db-space-current","title":"oracle-db-space-current-v1","name":"Oracle DB Space - Current","allowNoIndex":true},"override":true}'
echo

curl "${curl_args[@]}" -X POST \
  "${KIBANA_URL}${space_prefix}/api/saved_objects/_import?overwrite=true" \
  --form "file=@${ROOT}/kibana/oracle-space-dashboard.ndjson"
echo
echo 'Kibana data view ve Oracle DB Space dashboard import edildi.'
