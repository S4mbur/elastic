#!/usr/bin/env bash
set -euo pipefail

: "${ES_URL:?ES_URL tanımlanmalı}"
: "${ES_ADMIN_USER:?ES_ADMIN_USER tanımlanmalı}"
: "${ES_ADMIN_PASSWORD:?ES_ADMIN_PASSWORD tanımlanmalı}"

curl_args=(--silent --show-error --fail-with-body --user "${ES_ADMIN_USER}:${ES_ADMIN_PASSWORD}")
if [[ -n "${ES_CA_CERT:-}" ]]; then
  curl_args+=(--cacert "${ES_CA_CERT}")
fi

curl "${curl_args[@]}" "${ES_URL}/_cluster/health?pretty"
curl "${curl_args[@]}" "${ES_URL}/_cat/indices/oracle-db-space-*?v"
curl "${curl_args[@]}" "${ES_URL}/_transform/oracle-space-current/_stats?pretty"

