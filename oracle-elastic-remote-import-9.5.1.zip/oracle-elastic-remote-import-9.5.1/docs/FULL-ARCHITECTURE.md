# Oracle DB Space Command Center — Elastic Stack 9.5.1

Bu paket, görseldeki `VTB.TB_DB_SPACE_LOG` şemasını bozmadan Elasticsearch, Kibana, Logstash ve Metricbeat 9.5.1 ile güvenli bir alan/kapasite gözlemleme sistemi kurar.

## Sonuçta ne elde edilir?

- Table ve index boyutlarının günlük zaman serisi
- Kibana tarih seçiciyle istenen gün/aralık (`Last 24 hours`, `Last 3 days`, `Last 7 days`, absolute date range)
- Table ve index için aynı grafikte seçilebilir 1-90 takvim günlük MB/yüzde değişimi ve toplam boyut
- Tüm table/index boyutlarının güncel, aranabilir ve CSV'ye aktarılabilir listesi
- Schema bazında toplam alan ve en büyük 30 nesne
- Tablespace allocated/used/free/max-autoextend ve doluluk yüzdesi
- Database toplam kapasite trendi
- En güncel kaydı entity bazında tutan continuous Elasticsearch transform
- TLS'li Elasticsearch, ayrı least-privilege Logstash kullanıcısı ve salt-okunur dashboard kullanıcısı
- ILM ile 730 gün retention, günlük SLM snapshot, persisted queue/DLQ ve Stack Monitoring

## Neden mevcut iki pipeline doğrudan kullanılmadı?

Paylaşılan pipeline'lar her 5 dakikada 90 günlük ham tabloyu iki kez tarıyor; `TABLE_CURRENT`/`INDEX_CURRENT` ve growth dokümanlarını sürekli overwrite ediyor. Veri büyüdükçe Oracle CPU/I/O maliyeti yükselir, ayrıca current dokümanların eski `@timestamp` değeri Kibana time picker ile beklenmeyen şekilde kaybolabilir.

Bu pakette:

1. Oracle'dan yalnızca günlük “son snapshot” okunur.
2. Son 3 gün deterministik `_id` ile tekrar okunarak geç gelen kayıtlar düzeltilir, duplicate oluşmaz.
3. History günlük tarih indekslerinde saklanır.
4. Current görünüm continuous transform ile ayrı indekste tutulur.
5. 1-90 günlük farklar dashboard içindeki dinamik Vega hesabıyla üretilir; büyüme kopyaları depolanmaz.

## Kurulum

### 1. Oracle collector

Yetkili kullanıcıyla:

```sql
@sql/00_prerequisites_as_dba.sql
```

VTB kullanıcısıyla:

```sql
@sql/10_harden_existing_table.sql
@sql/20_capture_package.sql
@sql/30_scheduler_jobs.sql
EXEC VTB.PKG_DB_SPACE_OBS.CAPTURE_SEGMENTS;
EXEC VTB.PKG_DB_SPACE_OBS.CAPTURE_CAPACITY;
@sql/40_operational_checks.sql
```

Mevcut sistem `SEGMENT` ve `TOTAL_SPACE` satırlarını zaten üretiyorsa collector kurmadan table/index/database history hemen çalışır. Tablespace doluluk paneli için `20_capture_package.sql` içindeki kapasite satırları gerekir.

### 2. Ortam ayarı

PowerShell:

```powershell
Copy-Item .env.example .env
notepad .env
```

`.env` içinde en az `ORACLE_JDBC_URL`, `ORACLE_USER`, `ORACLE_PASSWORD` ve `SOURCE_DB` değerlerini girin. `GENERATE_ME` parolalarını elle değiştirmeyin; kurulum scripti güvenli değer üretir.

### 3. Elastic/Kibana kurulumu

Docker Desktop Linux engine çalışırken:

```powershell
.\scripts\install.ps1
```

Kibana: <http://localhost:5601>

- Yönetici: `elastic`
- Salt okunur kullanıcı: `oracle_space_viewer`
- Üretilen parolalar: `.env` (kaynak kontrolüne eklemeyin)

Dashboard adı: **Oracle DB Space | Command Center**

### 4. Ingest'i başlatma

```powershell
.\scripts\start-ingest.ps1
```

İlk belgeler geldikten sonra:

```powershell
.\scripts\activate-transform.ps1
```

Mevcut 365 günlük veriyi bir kez almak için:

```powershell
.\scripts\backfill.ps1 -Days 365
```

## Kibana'da gün ve nesne seçme

Dashboard sağ üst time picker:

- 1 günlük: `Last 24 hours` veya absolute başlangıç/bitiş
- 3 günlük: `Last 3 days`
- 1 haftalık: `Last 7 days`
- Takvim günü: `Absolute` ile 00:00–23:59 (`Europe/Istanbul`)

**Oracle | Dinamik Table / Index Trendi** panelindeki kontroller:

- **Karşılaştırma günü:** 1-90 arasında herhangi bir takvim günü (ör. 2, 5, 14, 30)
- **Nesne türü:** Table + Index, yalnız table veya yalnız index
- **Gösterim:** Toplam boyut (MB), seçilen güne göre değişim (MB) veya değişim (%)

Panel, en fazla 90 günlük karşılaştırmayı sınır saatlerinde de doğru kurmak için time picker başlangıcından önceki 91 günü yalnız hesaplama amacıyla getirir; grafikte sadece seçili tarih aralığı görünür. Eksik snapshot günleri `0 MB` kabul edilmez. Bu nedenle veri olmayan gün sahte bir küçülme üretmez; ilgili karşılaştırma noktası boş kalır. Bir `entity.id` filtresi seçilmezse grafik tek nesneyi değil, diğer KQL filtrelerine uyan table/index toplamını gösterir.

Tek bir index:

```kql
entity.id : "takascdb|index|OWNER|INDEX_NAME"
```

Tek bir table:

```kql
entity.id : "takascdb|table|OWNER|TABLE_NAME"
```

Diğer yararlı filtreler:

```kql
db.object.kind : "table"
db.object.kind : "index"
db.schema : "MY_SCHEMA"
db.tablespace : "USERS"
db.space.used.pct >= 80
```

“Oracle | Tüm Table ve Index Boyutları” paneli current indeksi kullanır ve global tarih aralığından bağımsız olarak son değeri gösterir. Discover'da **Oracle DB Space - Current** data view'ını açarak tüm kayıtları sıralayabilir ve CSV dışa aktarabilirsiniz.

## Yönetim

```powershell
.\scripts\health-check.ps1
docker compose --profile ingest logs -f logstash
docker compose stop
docker compose start
```

Verileri de kaldıran geri dönüşü zor komut `docker compose down -v` burada otomatik kullanılmaz.

Alarm eşikleri, yedekleme, HA ve ölçek önerileri için [OPERATIONS.md](OPERATIONS.md) dosyasına bakın.

## Dosya haritası

```text
compose.yaml                         Secure Elastic/Kibana/Logstash/Metricbeat
sql/                                Oracle collector, scheduler ve kontroller
logstash/sql/                       Optimize günlük snapshot sorguları
logstash/pipeline/                  Live + one-shot backfill pipeline'ları
elasticsearch/                      ILM, mappings, latest transform ve SLM
kibana/vega/                        Tarih/growth/capacity panel tanımları
kibana/oracle-space-dashboard.ndjson Otomatik import edilen dashboard
scripts/                             Kurulum, ingest, backfill ve health-check
```

## Sürüm ve mimari notu

Tüm Elastic image'ları tam olarak `9.5.1` olarak pinlidir. Oracle JDBC `ojdbc11` 23.26.3.0.0 image build sırasında Maven Central'dan alınır ve SHA-256 ile doğrulanır. Tek-node compose güvenli POC/küçük kurulum içindir; kurumsal HA topolojisi için [OPERATIONS.md](OPERATIONS.md) içindeki üç-node önerisini uygulayın.
