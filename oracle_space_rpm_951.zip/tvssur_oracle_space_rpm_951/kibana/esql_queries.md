# TVSSUR Kibana ES|QL Query List

Bu dosyadaki queryler Dashboard API import çalışmazsa Kibana > Dashboard > Add panel > Visualization (query) / ES|QL ile elle eklenebilir.

## Table dashboard (`tvssur-table`)

### total_current
```esql
FROM tvssur-table-space-v1 | WHERE metric_group == "TOTAL_SPACE_DAILY" AND object_name == "TOTAL_DATAFILES" AND @timestamp >= ?_tstart AND @timestamp < ?_tend | STATS total_space_mb = LAST(total_space_mb, @timestamp)
```

### total_diff
```esql
FROM tvssur-table-space-v1 | WHERE metric_group == "TOTAL_SPACE_DAILY" AND object_name == "TOTAL_DATAFILES" AND @timestamp >= ?_tstart AND @timestamp < ?_tend | STATS first_size_mb = FIRST(total_space_mb, @timestamp), last_size_mb = LAST(total_space_mb, @timestamp) | EVAL diff_mb = last_size_mb - first_size_mb | EVAL pct_change = CASE(first_size_mb == 0, null, diff_mb / first_size_mb * 100) | KEEP diff_mb, pct_change
```

### top_current
```esql
FROM tvssur-table-space-v1 | WHERE metric_group == "TABLE_DAILY" AND @timestamp >= ?_tstart AND @timestamp < ?_tend | STATS size_mb = LAST(current_size_mb, @timestamp) BY entity_name | SORT size_mb DESC | LIMIT 10
```

### top_only_current
```esql
FROM tvssur-table-space-v1 | WHERE metric_group == "TABLE_ONLY_DAILY" AND @timestamp >= ?_tstart AND @timestamp < ?_tend | STATS size_mb = LAST(current_size_mb, @timestamp) BY entity_name | SORT size_mb DESC | LIMIT 10
```

### top_growth_mb
```esql
FROM tvssur-table-space-v1 | WHERE metric_group == "TABLE_DAILY" AND @timestamp >= ?_tstart AND @timestamp < ?_tend | STATS first_size_mb = FIRST(current_size_mb, @timestamp), last_size_mb = LAST(current_size_mb, @timestamp), first_day = FIRST(log_day_str, @timestamp), last_day = LAST(log_day_str, @timestamp) BY entity_name | EVAL diff_mb = last_size_mb - first_size_mb | EVAL pct_change = CASE(first_size_mb == 0, null, diff_mb / first_size_mb * 100) | WHERE diff_mb > 0 | SORT diff_mb DESC | LIMIT 10
```

### top_growth_pct
```esql
FROM tvssur-table-space-v1 | WHERE metric_group == "TABLE_DAILY" AND @timestamp >= ?_tstart AND @timestamp < ?_tend | STATS first_size_mb = FIRST(current_size_mb, @timestamp), last_size_mb = LAST(current_size_mb, @timestamp) BY entity_name | EVAL diff_mb = last_size_mb - first_size_mb | EVAL pct_change = CASE(first_size_mb == 0, null, diff_mb / first_size_mb * 100) | WHERE pct_change > 0 | SORT pct_change DESC | LIMIT 10
```

### table_trend
```esql
FROM tvssur-table-space-v1 | WHERE metric_group == "TABLE_DAILY" AND @timestamp >= ?_tstart AND @timestamp < ?_tend | STATS size_mb = MAX(current_size_mb) BY log_day_str, entity_name | SORT log_day_str ASC | LIMIT 5000
```

### total_trend
```esql
FROM tvssur-table-space-v1 | WHERE metric_group == "TOTAL_SPACE_DAILY" AND object_name == "TOTAL_DATAFILES" AND @timestamp >= ?_tstart AND @timestamp < ?_tend | STATS total_space_mb = MAX(total_space_mb) BY log_day_str | SORT log_day_str ASC
```

### top_detail
```esql
FROM tvssur-table-space-v1 | WHERE metric_group == "TABLE_DAILY" AND @timestamp >= ?_tstart AND @timestamp < ?_tend | STATS first_size_mb = FIRST(current_size_mb, @timestamp), last_size_mb = LAST(current_size_mb, @timestamp), first_day = FIRST(log_day_str, @timestamp), last_day = LAST(log_day_str, @timestamp) BY entity_name | EVAL diff_mb = last_size_mb - first_size_mb | EVAL pct_change = CASE(first_size_mb == 0, null, diff_mb / first_size_mb * 100) | SORT diff_mb DESC | LIMIT 50
```

## Index dashboard (`tvssur-index`)

### top_current
```esql
FROM tvssur-index-space-v1 | WHERE metric_group == "INDEX_DAILY" AND @timestamp >= ?_tstart AND @timestamp < ?_tend | STATS size_mb = LAST(current_size_mb, @timestamp) BY entity_name | SORT size_mb DESC | LIMIT 10
```

### top_only_current
```esql
FROM tvssur-index-space-v1 | WHERE metric_group == "INDEX_ONLY_DAILY" AND @timestamp >= ?_tstart AND @timestamp < ?_tend | STATS size_mb = LAST(current_size_mb, @timestamp) BY entity_name | SORT size_mb DESC | LIMIT 10
```

### top_growth_mb
```esql
FROM tvssur-index-space-v1 | WHERE metric_group == "INDEX_DAILY" AND @timestamp >= ?_tstart AND @timestamp < ?_tend | STATS first_size_mb = FIRST(current_size_mb, @timestamp), last_size_mb = LAST(current_size_mb, @timestamp), first_day = FIRST(log_day_str, @timestamp), last_day = LAST(log_day_str, @timestamp) BY entity_name | EVAL diff_mb = last_size_mb - first_size_mb | EVAL pct_change = CASE(first_size_mb == 0, null, diff_mb / first_size_mb * 100) | WHERE diff_mb > 0 | SORT diff_mb DESC | LIMIT 10
```

### top_growth_pct
```esql
FROM tvssur-index-space-v1 | WHERE metric_group == "INDEX_DAILY" AND @timestamp >= ?_tstart AND @timestamp < ?_tend | STATS first_size_mb = FIRST(current_size_mb, @timestamp), last_size_mb = LAST(current_size_mb, @timestamp) BY entity_name | EVAL diff_mb = last_size_mb - first_size_mb | EVAL pct_change = CASE(first_size_mb == 0, null, diff_mb / first_size_mb * 100) | WHERE pct_change > 0 | SORT pct_change DESC | LIMIT 10
```

### index_trend
```esql
FROM tvssur-index-space-v1 | WHERE metric_group == "INDEX_DAILY" AND @timestamp >= ?_tstart AND @timestamp < ?_tend | STATS size_mb = MAX(current_size_mb) BY log_day_str, entity_name | SORT log_day_str ASC | LIMIT 5000
```

### top_detail
```esql
FROM tvssur-index-space-v1 | WHERE metric_group == "INDEX_DAILY" AND @timestamp >= ?_tstart AND @timestamp < ?_tend | STATS first_size_mb = FIRST(current_size_mb, @timestamp), last_size_mb = LAST(current_size_mb, @timestamp), first_day = FIRST(log_day_str, @timestamp), last_day = LAST(log_day_str, @timestamp) BY entity_name | EVAL diff_mb = last_size_mb - first_size_mb | EVAL pct_change = CASE(first_size_mb == 0, null, diff_mb / first_size_mb * 100) | SORT diff_mb DESC | LIMIT 50
```
