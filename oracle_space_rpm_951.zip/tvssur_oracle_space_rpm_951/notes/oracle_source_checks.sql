-- Kaynak tablo var mı?
SELECT owner, table_name
FROM all_tables
WHERE owner = 'VTB'
  AND table_name = 'TB_DB_SPACE_LOG';

-- Kolonlar
SELECT column_name, data_type
FROM all_tab_columns
WHERE owner = 'VTB'
  AND table_name = 'TB_DB_SPACE_LOG'
ORDER BY column_id;

-- Son log tarihleri
SELECT MIN(log_date) AS min_log_date, MAX(log_date) AS max_log_date, COUNT(*) AS row_count
FROM VTB.TB_DB_SPACE_LOG;

-- Log type dağılımı
SELECT UPPER(REPLACE(log_type, ' ', '_')) AS log_type_norm, COUNT(*) AS cnt
FROM VTB.TB_DB_SPACE_LOG
WHERE log_date >= TRUNC(SYSDATE) - 120
GROUP BY UPPER(REPLACE(log_type, ' ', '_'))
ORDER BY cnt DESC;

-- Segment type dağılımı
SELECT UPPER(segment_type) AS segment_type, COUNT(*) AS cnt
FROM VTB.TB_DB_SPACE_LOG
WHERE log_date >= TRUNC(SYSDATE) - 120
  AND UPPER(REPLACE(log_type, ' ', '_')) = 'SEGMENT'
GROUP BY UPPER(segment_type)
ORDER BY cnt DESC;

-- TOTAL_DATAFILES var mı?
SELECT log_date, object_name, size_mb
FROM VTB.TB_DB_SPACE_LOG
WHERE UPPER(REPLACE(log_type, ' ', '_')) = 'TOTAL_SPACE'
  AND UPPER(NVL(object_name, 'TOTAL_DATAFILES')) = 'TOTAL_DATAFILES'
ORDER BY log_date DESC
FETCH FIRST 10 ROWS ONLY;
