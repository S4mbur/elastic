#!/usr/bin/env bash
set -Eeuo pipefail

# Script elle env almamışsa ortak env dosyasını oku.
if [[ -f /etc/sysconfig/logstash-tvssur-space ]]; then
  set -a
  # shellcheck disable=SC1091
  source /etc/sysconfig/logstash-tvssur-space
  set +a
fi

ES_URL="${ES_URL:-${ES_HOSTS:-https://localhost:9200}}"
ES_CURL_INSECURE="${ES_CURL_INSECURE:-true}"
ES_USER="${ES_USER:-elastic}"
ES_PASSWORD="${ES_PASSWORD:-}"
ES_API_KEY="${ES_API_KEY:-}"
MAX_WAIT_SECONDS="${MAX_WAIT_SECONDS:-420}"
POLL_SECONDS="${POLL_SECONDS:-15}"

TABLE_INDEX="tvssur-table-space-v1"
INDEX_INDEX="tvssur-index-space-v1"

CURL_COMMON=(-fsS)
if [[ "${ES_CURL_INSECURE}" == "true" ]]; then
  CURL_COMMON+=(-k)
fi
AUTH_ARGS=()
if [[ -n "${ES_API_KEY}" ]]; then
  AUTH_ARGS=(-H "Authorization: ApiKey ${ES_API_KEY}")
elif [[ -n "${ES_PASSWORD}" ]]; then
  AUTH_ARGS=(-u "${ES_USER}:${ES_PASSWORD}")
fi

count_index() {
  local idx="$1"
  curl "${CURL_COMMON[@]}" "${AUTH_ARGS[@]}" "${ES_URL}/${idx}/_count" 2>/dev/null \
    | python3 -c 'import json,sys; print(json.load(sys.stdin).get("count",0))' 2>/dev/null || echo 0
}

groups() {
  local idx="$1"
  echo
  echo "${idx} metric_group dağılımı:"
  curl "${CURL_COMMON[@]}" "${AUTH_ARGS[@]}" -X POST "${ES_URL}/${idx}/_search" \
    -H 'Content-Type: application/json' \
    -d '{"size":0,"aggs":{"g":{"terms":{"field":"metric_group","size":30}}}}' \
    | python3 -c 'import json,sys; d=json.load(sys.stdin); [print("  %s: %s"%(b["key"], b["doc_count"])) for b in d.get("aggregations",{}).get("g",{}).get("buckets",[])]'
}

echo "Logstash config test"
sudo /usr/share/logstash/bin/logstash --path.settings /etc/logstash -f /etc/logstash/conf.d --config.test_and_exit

echo "Logstash restart"
sudo systemctl restart logstash
sudo systemctl --no-pager status logstash || true

echo
echo "JDBC schedule beklenecek. İlk veri akışı birkaç dakika sürebilir."
elapsed=0
while (( elapsed <= MAX_WAIT_SECONDS )); do
  t=$(count_index "${TABLE_INDEX}")
  i=$(count_index "${INDEX_INDEX}")
  printf '[%3ss] table_docs=%s index_docs=%s\n' "${elapsed}" "${t}" "${i}"
  if (( t > 0 && i > 0 )); then
    break
  fi
  sleep "${POLL_SECONDS}"
  elapsed=$((elapsed + POLL_SECONDS))
done

groups "${TABLE_INDEX}"
groups "${INDEX_INDEX}"

echo
echo "Logstash son loglar:"
sudo journalctl -u logstash -n 120 --no-pager
