#!/usr/bin/env bash
set -Eeuo pipefail

# Script elle env almamışsa ortak env dosyasını oku.
if [[ -f /etc/sysconfig/logstash-tvssur-space ]]; then
  set -a
  # shellcheck disable=SC1091
  source /etc/sysconfig/logstash-tvssur-space
  set +a
fi

ES_URL="${ES_URL:-${ES_HOSTS:-https://localhost:9200}}"
ES_CURL_INSECURE="${ES_CURL_INSECURE:-true}"
ES_USER="${ES_USER:-elastic}"
ES_PASSWORD="${ES_PASSWORD:-}"
ES_API_KEY="${ES_API_KEY:-}"
AUTO_YES="${AUTO_YES:-0}"

TABLE_INDEX="tvssur-table-space-v1"
INDEX_INDEX="tvssur-index-space-v1"

CURL_COMMON=(-fsS)
if [[ "${ES_CURL_INSECURE}" == "true" ]]; then
  CURL_COMMON+=(-k)
fi

AUTH_ARGS=()
if [[ -n "${ES_API_KEY}" ]]; then
  AUTH_ARGS=(-H "Authorization: ApiKey ${ES_API_KEY}")
elif [[ -n "${ES_PASSWORD}" ]]; then
  AUTH_ARGS=(-u "${ES_USER}:${ES_PASSWORD}")
fi

confirm() {
  if [[ "${AUTO_YES}" == "1" ]]; then
    return 0
  fi
  echo "Bu işlem şu iki indexi silip tekrar oluşturacak:"
  echo "  - ${TABLE_INDEX}"
  echo "  - ${INDEX_INDEX}"
  echo "Kibana dashboard indexlerine (.kibana*) dokunmaz."
  read -r -p "Devam? [yes/no] " ans
  [[ "${ans}" == "yes" ]]
}

create_index() {
  local index_name="$1"
  echo
  echo "Index oluşturuluyor: ${index_name}"
  curl "${CURL_COMMON[@]}" "${AUTH_ARGS[@]}" -X PUT "${ES_URL}/${index_name}" \
    -H 'Content-Type: application/json' \
    -d @- <<'JSON'
{
  "settings": {
    "index.max_result_window": 100000
  },
  "mappings": {
    "properties": {
      "@timestamp": { "type": "date" },
      "source_db": { "type": "keyword" },
      "metric_type": { "type": "keyword" },
      "space_kind": { "type": "keyword" },
      "metric_group": { "type": "keyword" },
      "owner": { "type": "keyword" },
      "object_name": { "type": "keyword" },
      "entity_name": { "type": "keyword" },
      "segment_type": { "type": "keyword" },
      "log_day": { "type": "date" },
      "log_day_str": { "type": "keyword" },
      "day_num": { "type": "integer" },
      "period_days": { "type": "integer" },
      "log_date": { "type": "date" },
      "current_size_mb": { "type": "double" },
      "previous_size_mb": { "type": "double" },
      "diff_mb": { "type": "double" },
      "pct_change": { "type": "double" },
      "total_space_mb": { "type": "double" },
      "doc_id": { "type": "keyword" }
    }
  }
}
JSON
}

confirm || { echo "İptal edildi."; exit 1; }

echo "Elasticsearch kontrol ediliyor: ${ES_URL}"
curl "${CURL_COMMON[@]}" "${AUTH_ARGS[@]}" "${ES_URL}/_cluster/health?pretty"

echo
printf 'Logstash durdurulsun mu? [ENTER: evet, Ctrl+C: çık] '
read -r _
systemctl stop logstash || true

echo "Indexler siliniyor..."
curl "${CURL_COMMON[@]}" "${AUTH_ARGS[@]}" -X DELETE "${ES_URL}/${TABLE_INDEX}?ignore_unavailable=true" >/dev/null
curl "${CURL_COMMON[@]}" "${AUTH_ARGS[@]}" -X DELETE "${ES_URL}/${INDEX_INDEX}?ignore_unavailable=true" >/dev/null

create_index "${TABLE_INDEX}"
create_index "${INDEX_INDEX}"

echo
echo "Oluşan indexler:"
curl "${CURL_COMMON[@]}" "${AUTH_ARGS[@]}" "${ES_URL}/_cat/indices/${TABLE_INDEX},${INDEX_INDEX}?v"

echo
echo "Tamam. Şimdi Logstash config test + restart yapabilirsin:"
echo "  sudo /usr/share/logstash/bin/logstash --path.settings /etc/logstash -f /etc/logstash/conf.d --config.test_and_exit"
echo "  sudo systemctl restart logstash"
