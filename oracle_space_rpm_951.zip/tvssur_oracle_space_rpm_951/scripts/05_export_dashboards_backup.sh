#!/usr/bin/env bash
set -Eeuo pipefail

# Script elle env almamışsa ortak env dosyasını oku.
if [[ -f /etc/sysconfig/logstash-tvssur-space ]]; then
  set -a
  # shellcheck disable=SC1091
  source /etc/sysconfig/logstash-tvssur-space
  set +a
fi

KIBANA_URL="${KIBANA_URL:-https://localhost:5601}"
KIBANA_CURL_INSECURE="${KIBANA_CURL_INSECURE:-true}"
KIBANA_USER="${KIBANA_USER:-elastic}"
KIBANA_PASSWORD="${KIBANA_PASSWORD:-}"
KIBANA_API_KEY="${KIBANA_API_KEY:-}"
OUT_FILE="${OUT_FILE:-kibana_tvssur_backup_$(date +%Y%m%d_%H%M%S).ndjson}"

CURL_COMMON=(-fsS)
if [[ "${KIBANA_CURL_INSECURE}" == "true" ]]; then
  CURL_COMMON+=(-k)
fi
AUTH_ARGS=()
if [[ -n "${KIBANA_API_KEY}" ]]; then
  AUTH_ARGS=(-H "Authorization: ApiKey ${KIBANA_API_KEY}")
elif [[ -n "${KIBANA_PASSWORD}" ]]; then
  AUTH_ARGS=(-u "${KIBANA_USER}:${KIBANA_PASSWORD}")
fi

curl "${CURL_COMMON[@]}" "${AUTH_ARGS[@]}" \
  -X POST "${KIBANA_URL%/}/api/saved_objects/_export" \
  -H "kbn-xsrf: true" \
  -H "Content-Type: application/json" \
  -d '{"type":["dashboard"],"includeReferencesDeep":true}' \
  -o "${OUT_FILE}"

echo "Backup alındı: ${OUT_FILE}"
