#!/usr/bin/env bash
set -Eeuo pipefail

# Script elle env almamışsa ortak env dosyasını oku.
if [[ -f /etc/sysconfig/logstash-tvssur-space ]]; then
  set -a
  # shellcheck disable=SC1091
  source /etc/sysconfig/logstash-tvssur-space
  set +a
fi

KIBANA_URL="${KIBANA_URL:-https://localhost:5601}"
KIBANA_CURL_INSECURE="${KIBANA_CURL_INSECURE:-true}"
KIBANA_USER="${KIBANA_USER:-elastic}"
KIBANA_PASSWORD="${KIBANA_PASSWORD:-}"
KIBANA_API_KEY="${KIBANA_API_KEY:-}"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

CURL_COMMON=(-fsS)
if [[ "${KIBANA_CURL_INSECURE}" == "true" ]]; then
  CURL_COMMON+=(-k)
fi

AUTH_ARGS=()
if [[ -n "${KIBANA_API_KEY}" ]]; then
  AUTH_ARGS=(-H "Authorization: ApiKey ${KIBANA_API_KEY}")
elif [[ -n "${KIBANA_PASSWORD}" ]]; then
  AUTH_ARGS=(-u "${KIBANA_USER}:${KIBANA_PASSWORD}")
fi

create_dash() {
  local file="$1"
  echo
  echo "Dashboard oluşturuluyor: ${file}"
  curl "${CURL_COMMON[@]}" "${AUTH_ARGS[@]}" \
    -X POST "${KIBANA_URL%/}/api/dashboards" \
    -H "kbn-xsrf: true" \
    -H "Content-Type: application/json" \
    -d @"${file}" | python3 -m json.tool
}

echo "Kibana kontrol ediliyor: ${KIBANA_URL}"
curl "${CURL_COMMON[@]}" "${AUTH_ARGS[@]}" "${KIBANA_URL%/}/api/status" -H "kbn-xsrf: true" >/dev/null

create_dash "${ROOT_DIR}/dashboards_api/tvssur-table.dashboard.json"
create_dash "${ROOT_DIR}/dashboards_api/tvssur-index.dashboard.json"

echo
echo "Tamam. Kibana > Dashboards altında şu isimleri ara:"
echo "  - tvssur-table"
echo "  - tvssur-index"
echo
echo "Not: Bu script her çalıştığında yeni dashboard oluşturabilir. Temiz ortam için bir kere çalıştır."
