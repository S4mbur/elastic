#!/usr/bin/env bash
set -Eeuo pipefail

# Script elle env almamışsa ortak env dosyasını oku.
if [[ -f /etc/sysconfig/logstash-tvssur-space ]]; then
  set -a
  # shellcheck disable=SC1091
  source /etc/sysconfig/logstash-tvssur-space
  set +a
fi

ES_URL="${ES_URL:-${ES_HOSTS:-https://localhost:9200}}"
ES_CURL_INSECURE="${ES_CURL_INSECURE:-true}"
ES_USER="${ES_USER:-elastic}"
ES_PASSWORD="${ES_PASSWORD:-}"
ES_API_KEY="${ES_API_KEY:-}"

CURL_COMMON=(-fsS)
if [[ "${ES_CURL_INSECURE}" == "true" ]]; then
  CURL_COMMON+=(-k)
fi
AUTH_ARGS=()
if [[ -n "${ES_API_KEY}" ]]; then
  AUTH_ARGS=(-H "Authorization: ApiKey ${ES_API_KEY}")
elif [[ -n "${ES_PASSWORD}" ]]; then
  AUTH_ARGS=(-u "${ES_USER}:${ES_PASSWORD}")
fi

for idx in tvssur-table-space-v1 tvssur-index-space-v1; do
  echo
  echo "=== ${idx} ==="
  curl "${CURL_COMMON[@]}" "${AUTH_ARGS[@]}" "${ES_URL}/_cat/indices/${idx}?v" || true
  curl "${CURL_COMMON[@]}" "${AUTH_ARGS[@]}" -X POST "${ES_URL}/${idx}/_search" \
    -H 'Content-Type: application/json' \
    -d '{"size":0,"aggs":{"metric_group":{"terms":{"field":"metric_group","size":30}},"last_doc":{"max":{"field":"@timestamp"}}}}' \
    | python3 -m json.tool

done
