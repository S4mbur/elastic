#!/usr/bin/env bash
set -Eeuo pipefail

PROFILE="${1:-auth}"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ "${PROFILE}" != "auth" && "${PROFILE}" != "noauth" ]]; then
  echo "Kullanım: sudo bash scripts/00_install_logstash_confs.sh auth|noauth" >&2
  exit 1
fi

if [[ ${EUID} -ne 0 ]]; then
  echo "Bu script root ile çalışmalı: sudo bash scripts/00_install_logstash_confs.sh ${PROFILE}" >&2
  exit 1
fi

echo "[1/5] Logstash conf klasörü hazırlanıyor"
mkdir -p /etc/logstash/conf.d

# Bu proje dosyalarını eski kopyalarından temizle; başka conf dosyalarına dokunmaz.
rm -f /etc/logstash/conf.d/10-tvssur-table-space.conf
rm -f /etc/logstash/conf.d/20-tvssur-index-space.conf

if [[ "${PROFILE}" == "auth" ]]; then
  cp "${ROOT_DIR}/logstash/conf.d_auth/10-tvssur-table-space.conf" /etc/logstash/conf.d/
  cp "${ROOT_DIR}/logstash/conf.d_auth/20-tvssur-index-space.conf" /etc/logstash/conf.d/
else
  cp "${ROOT_DIR}/logstash/conf.d_noauth/10-tvssur-table-space.conf" /etc/logstash/conf.d/
  cp "${ROOT_DIR}/logstash/conf.d_noauth/20-tvssur-index-space.conf" /etc/logstash/conf.d/
fi

chown root:root /etc/logstash/conf.d/10-tvssur-table-space.conf /etc/logstash/conf.d/20-tvssur-index-space.conf
chmod 0644 /etc/logstash/conf.d/10-tvssur-table-space.conf /etc/logstash/conf.d/20-tvssur-index-space.conf

echo "[2/5] Env dosyası hazırlanıyor"
if [[ ! -f /etc/sysconfig/logstash-tvssur-space ]]; then
  cp "${ROOT_DIR}/env/logstash-tvssur-space.env.example" /etc/sysconfig/logstash-tvssur-space
  chmod 0600 /etc/sysconfig/logstash-tvssur-space
  echo "Oluşturuldu: /etc/sysconfig/logstash-tvssur-space"
else
  echo "Zaten var, üstüne yazılmadı: /etc/sysconfig/logstash-tvssur-space"
fi

echo "[3/5] Systemd override kuruluyor"
mkdir -p /etc/systemd/system/logstash.service.d
cp "${ROOT_DIR}/systemd/logstash-tvssur-env.conf" /etc/systemd/system/logstash.service.d/tvssur-env.conf
chmod 0644 /etc/systemd/system/logstash.service.d/tvssur-env.conf
systemctl daemon-reload

echo "[4/5] JDBC driver klasörü hazırlanıyor"
mkdir -p /opt/logstash-drivers
chmod 0755 /opt/logstash-drivers

echo "[5/5] Tamam"
echo
cat <<MSG
Şimdi şunları düzenle/kontrol et:
  sudo vi /etc/sysconfig/logstash-tvssur-space
  sudo cp ojdbc11.jar /opt/logstash-drivers/ojdbc11.jar
  sudo chmod 644 /opt/logstash-drivers/ojdbc11.jar

Sonra:
  sudo /usr/share/logstash/bin/logstash --path.settings /etc/logstash -f /etc/logstash/conf.d --config.test_and_exit
MSG
