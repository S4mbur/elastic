# TVSSUR Oracle Space Dashboard - RPM / Elastic 9.5.1

Bu paket temiz RPM kurulumu olan Elastic Stack 9.5.1 için hazırlanmıştır. Docker kullanılmaz.

Kaynak tablo:

```sql
VTB.TB_DB_SPACE_LOG
```

Oluşturulacak Elasticsearch indexleri:

```text
tvssur-table-space-v1
tvssur-index-space-v1
```

Oluşturulacak Kibana dashboard isimleri:

```text
tvssur-table
tvssur-index
```

Dashboardlar ES|QL tabanlıdır. Kibana sağ üstteki time picker `Last 7 days`, `Last 30 days` gibi ayarlandığında “seçili aralıktaki ilk mevcut kayıt - son mevcut kayıt” farkını hesaplar. Dünden öncesi veri yoksa olmayan gün üretmez; sadece mevcut günleri kullanır.

---

## 0. Paket içeriği

```text
logstash/conf.d_auth/10-tvssur-table-space.conf
logstash/conf.d_auth/20-tvssur-index-space.conf
logstash/conf.d_noauth/10-tvssur-table-space.conf
logstash/conf.d_noauth/20-tvssur-index-space.conf

env/logstash-tvssur-space.env.example
systemd/logstash-tvssur-env.conf

scripts/00_install_logstash_confs.sh
scripts/01_create_or_reset_indices.sh
scripts/02_start_logstash_and_check.sh
scripts/03_check_space_indices.sh
scripts/04_create_dashboards_api.sh
scripts/05_export_dashboards_backup.sh

dashboards_api/tvssur-table.dashboard.json
dashboards_api/tvssur-index.dashboard.json
kibana/esql_queries.md
notes/oracle_source_checks.sql
```

---

## 1. Dosyayı aç

```bash
unzip tvssur_oracle_space_rpm_951.zip
cd tvssur_oracle_space_rpm_951
```

---

## 2. Logstash JDBC plugin kontrolü

```bash
sudo /usr/share/logstash/bin/logstash-plugin list | grep -E 'jdbc|logstash-integration-jdbc'
```

Çıkmazsa internetli ortamda:

```bash
sudo /usr/share/logstash/bin/logstash-plugin install logstash-integration-jdbc
```

Offline ortamdaysan plugin pack ile kurulmalı.

---

## 3. Oracle JDBC driver koy

```bash
sudo mkdir -p /opt/logstash-drivers
sudo cp ojdbc11.jar /opt/logstash-drivers/ojdbc11.jar
sudo chmod 755 /opt/logstash-drivers
sudo chmod 644 /opt/logstash-drivers/ojdbc11.jar
```

---

## 4. Logstash conf dosyalarını kur

Elasticsearch security/HTTPS açıksa:

```bash
sudo bash scripts/00_install_logstash_confs.sh auth
```

Security kapalı HTTP ise:

```bash
sudo bash scripts/00_install_logstash_confs.sh noauth
```

Bu script sadece şu dosyaları kurar:

```text
/etc/logstash/conf.d/10-tvssur-table-space.conf
/etc/logstash/conf.d/20-tvssur-index-space.conf
/etc/sysconfig/logstash-tvssur-space
/etc/systemd/system/logstash.service.d/tvssur-env.conf
```

---

## 5. Env dosyasını düzenle

```bash
sudo vi /etc/sysconfig/logstash-tvssur-space
```

Özellikle şunları düzelt:

```bash
ORACLE_JDBC_URL="jdbc:oracle:thin:@//HOST:PORT/SERVICE_NAME"
ORACLE_USER="VTB"
ORACLE_PASSWORD="CHANGE_ME"

ES_URL="https://localhost:9200"
ES_HOSTS="https://localhost:9200"
ES_USER="elastic"
ES_PASSWORD="CHANGE_ME"
ES_CA_CERT="/etc/elasticsearch/certs/http_ca.crt"

KIBANA_URL="https://localhost:5601"
KIBANA_USER="elastic"
KIBANA_PASSWORD="CHANGE_ME"
```

`JDBC_SCHEDULE` günlük space datası için 15 dakikada bir çalışacak şekilde bırakıldı:

```bash
JDBC_SCHEDULE="*/15 * * * *"
```

İstersen 5 dakikada bire çekebilirsin:

```bash
JDBC_SCHEDULE="*/5 * * * *"
```

---

## 6. Oracle kaynak tabloyu kontrol et

İstersen DB tarafında şu dosyadaki sorguları çalıştır:

```text
notes/oracle_source_checks.sql
```

Beklenen segment tipleri:

```text
TABLE
TABLE PARTITION
TABLE SUBPARTITION
INDEX
INDEX PARTITION
INDEX SUBPARTITION
```

Beklenen total kayıt:

```text
LOG_TYPE = TOTAL_SPACE
OBJECT_NAME = TOTAL_DATAFILES
```

---

## 7. Elasticsearch indexlerini oluştur

Bu script `tvssur-table-space-v1` ve `tvssur-index-space-v1` indexlerini silip mapping ile tekrar oluşturur. `.kibana*` indexlerine dokunmaz.

```bash
sudo bash scripts/01_create_or_reset_indices.sh
```

Onaysız çalıştırmak istersen:

```bash
sudo AUTO_YES=1 bash scripts/01_create_or_reset_indices.sh
```

---

## 8. Logstash config test + restart

```bash
sudo /usr/share/logstash/bin/logstash \
  --path.settings /etc/logstash \
  -f /etc/logstash/conf.d \
  --config.test_and_exit
```

Sonra:

```bash
sudo systemctl daemon-reload
sudo systemctl restart logstash
sudo journalctl -u logstash -f
```

Tek komutla test + restart + count bekleme için:

```bash
bash scripts/02_start_logstash_and_check.sh
```

---

## 9. Elasticsearch veri kontrolü

```bash
bash scripts/03_check_space_indices.sh
```

Table indexte şunlar görünmeli:

```text
TABLE_DAILY
TABLE_ONLY_DAILY
TABLE_CURRENT
TABLE_ONLY_CURRENT
TOTAL_SPACE_DAILY
TOTAL_SPACE_CURRENT
```

Index indexte şunlar görünmeli:

```text
INDEX_DAILY
INDEX_ONLY_DAILY
INDEX_CURRENT
INDEX_ONLY_CURRENT
```

---

## 10. Dashboardları oluştur

Kibana 9.5.1 Dashboard API ile iki dashboard oluşturmak için:

```bash
bash scripts/04_create_dashboards_api.sh
```

Sonra Kibana > Dashboards altında ara:

```text
tvssur-table
tvssur-index
```

Bu script her çalıştırıldığında yeni dashboard oluşturabilir. Temiz ortamda bir kere çalıştırman yeterli.

Dashboard API tarafında hata alırsan Kibana UI’dan manuel eklemek için queryler burada:

```text
kibana/esql_queries.md
```

Manuel ekleme yolu:

```text
Dashboard > Create dashboard > Add panel > Visualization (query) / ES|QL
```

---

## 11. Time picker mantığı

Dashboard panellerinde fark hesabı şu mantıkla yapılır:

```text
seçili zaman aralığındaki son mevcut size - seçili zaman aralığındaki ilk mevcut size
```

Örnek:

```text
Time picker = Last 7 days
Veri sadece dün ve bugün var
Fark = bugünkü size - dünkü size
```

Yani olmayan günler sıfır veya boş üretilmez.

---

## 12. Dashboard panel mantığı

### tvssur-table

```text
TOTAL_DATAFILES current MB
TOTAL_DATAFILES selected range diff
TOTAL_DATAFILES trend
Top 10 table total size MB
Top 10 non-partition table size MB
Top 10 table growth MB in selected range
Top 10 table growth % in selected range
Table size trend in selected range
Table selected-range details
```

`Top 10 table total size MB` paneli `TABLE + TABLE PARTITION + TABLE SUBPARTITION` toplamıdır.

`Top 10 non-partition table size MB` paneli sadece `SEGMENT_TYPE = TABLE` olanları gösterir.

### tvssur-index

```text
Top 10 index total size MB
Top 10 non-partition index size MB
Top 10 index growth MB in selected range
Top 10 index growth % in selected range
Index size trend in selected range
Index selected-range details
```

`Top 10 index total size MB` paneli `INDEX + INDEX PARTITION + INDEX SUBPARTITION` toplamıdır.

`Top 10 non-partition index size MB` paneli sadece `SEGMENT_TYPE = INDEX` olanları gösterir.

---

## 13. Backup

Dashboardları yedeklemek için:

```bash
bash scripts/05_export_dashboards_backup.sh
```

Bu NDJSON dosyasını daha sonra Kibana Saved Objects import ile geri yükleyebilirsin.
